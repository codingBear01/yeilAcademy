const btn = document.querySelector('button');
const menu = document.querySelector('.menu');
console.log(menu.classList[1]);

btn.addEventListener('click', () => {
  if (menu.classList[1] === 'inactive') {
    menu.classList.remove('inactive');
    menu.classList.add('active');
  } else {
    menu.classList.remove('active');
    menu.classList.add('inactive');
  }
});
