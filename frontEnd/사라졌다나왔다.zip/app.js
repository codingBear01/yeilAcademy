const menu = document.querySelector('.menu');
const text = document.querySelector('.text');

// menu.forEach((div) => {
//   div.addEventListener('mouseenter', () => {
//     text.classList.remove('inactive');
//     text.classList.add('active');
//   });
// });

// menu.forEach((div) => {
//   div.addEventListener('mouseout', () => {
//     text.classList.remove('inactive');
//     text.classList.add('active');
//   });
// });

menu.addEventListener('mouseenter', () => {
  text.classList.remove('inactive');
  text.classList.add('active');
});

menu.addEventListener('mouseout', () => {
  text.classList.remove('active');
  text.classList.add('inactive');
});
